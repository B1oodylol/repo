如果你的国家有三个运营商  中国移动/中国电信/中国联通 那么你可以放三个图标在这里
中国移动@3x.png
中国电信@3x.png
中国联通@3x.png
当你开启了NiceCaller拨号选卡-自动识别运营商图标后,如果这里有合适的图标,插件将自动使用符合你运营商的图标


if there have three operators in your country CarrierA/CarrierB/CarrierC then you can put the three png files here
CarrierA@3x.png
CarrierB@3X.png
CarrierC@3X.png
When you enable the Nicecaller dial card to automatically recognize the carrier icon, Nicecaller will automatically use the icon that matches your carrier if there is a suitable icon